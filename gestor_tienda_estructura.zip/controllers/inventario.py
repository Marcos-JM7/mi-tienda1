# Aquí irán las funciones para manejar inventario

def agregar_producto():
    pass
