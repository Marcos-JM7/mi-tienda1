# Archivo principal de la aplicación

print('Bienvenido al Gestor de Tienda')
