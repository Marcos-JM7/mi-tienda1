class Producto:
    def __init__(self, id, nombre, categoria, precio_compra, precio_venta, stock, fecha_ingreso):
        self.id = id
        self.nombre = nombre
        self.categoria = categoria
        self.precio_compra = precio_compra
        self.precio_venta = precio_venta
        self.stock = stock
        self.fecha_ingreso = fecha_ingreso
